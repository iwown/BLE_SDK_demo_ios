//
//  TestBLEZg.h
//  BLEMidAutumnTests
//
//  Created by A$CE on 2018/1/11.
//  Copyright © 2018年 A$CE. All rights reserved.
//

#import "BLEZg.h"

@interface TestBLEZg : BLEZg

@end
