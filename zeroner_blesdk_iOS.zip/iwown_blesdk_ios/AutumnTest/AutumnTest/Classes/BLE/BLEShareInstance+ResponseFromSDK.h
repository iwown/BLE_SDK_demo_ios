//
//  BLEShareInstance+ResponseFromSDK.h
//  linyi
//
//  Created by CY on 2017/11/2.
//  Copyright © 2017年 com.kunekt.healthy. All rights reserved.
//

#import "BLEShareInstance.h"

@interface BLEShareInstance (ResponseFromSDK)
@end
