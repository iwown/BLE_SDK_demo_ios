//
//  ecgDemoViewController.h
//  AutumnTest
//
//  Created by ChenWu on 2018/3/19.
//  Copyright © 2018年 A$CE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ecgDemoViewController : UIViewController

@end
