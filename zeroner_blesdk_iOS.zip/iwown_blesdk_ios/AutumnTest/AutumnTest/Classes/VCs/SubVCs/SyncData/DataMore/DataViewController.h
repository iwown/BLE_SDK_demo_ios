//
//  DataViewController.h
//  AutumnTest
//
//  Created by A$CE on 2018/2/8.
//  Copyright © 2018年 A$CE. All rights reserved.
//

#import "BaseViewController.h"

@interface DataViewController : BaseViewController

@end
