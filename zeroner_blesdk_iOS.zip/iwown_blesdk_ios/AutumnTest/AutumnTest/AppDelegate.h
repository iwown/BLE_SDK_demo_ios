//
//  AppDelegate.h
//  AutumnTest
//
//  Created by A$CE on 2017/10/17.
//  Copyright © 2017年 A$CE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

