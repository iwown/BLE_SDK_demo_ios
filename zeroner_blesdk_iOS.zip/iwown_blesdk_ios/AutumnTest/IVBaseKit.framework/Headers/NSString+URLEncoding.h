//
//  NSString+URLEncoding.h
//  ZLYIwown
//
//  Created by west on 16/6/4.
//  Copyright © 2016年 Iwown. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (URLEncoding)

- (NSString *)urlEncodeString;

@end
