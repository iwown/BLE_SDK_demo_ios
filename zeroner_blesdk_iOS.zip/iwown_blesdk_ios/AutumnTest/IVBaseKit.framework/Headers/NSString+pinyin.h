//
//  NSString+pinyin.h
//  iosapp
//
//  Created by 王晨 on 15/8/25.
//  Copyright © 2015年 oschina. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (pinyin)
//- (NSString*)pinyinFirst;
- (NSString*)pinyin;
@end
