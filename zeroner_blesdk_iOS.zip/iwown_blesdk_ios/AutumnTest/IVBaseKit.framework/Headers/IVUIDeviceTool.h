//
//  IVUIDeviceTool.h
//  ZeronerHealthPro
//
//  Created by ChenWu on 2017/8/30.
//  Copyright © 2017年 iwown. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IVUIDeviceTool : NSObject
+ (NSString *)GetCurrentDeviceModel;
@end
