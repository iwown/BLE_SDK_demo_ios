### Dong2睡眠Json字段说明

##### 更新日志
* 2018-12月 去掉HRV 1.3 曹凯
* 2018-11月 增加SEQ 1.2 曹凯
* 2018-10月 修改时间格式 1.1 曹凯
* 2018-8月 初稿 1.0 曹凯
##### 结构

```
[//分钟数据数组*
	{
		"Q":1573,//SEQ
		"T":[],//时分数组，为此处只有Hour和minute。
		"E":{},//数据分类
		"P":{
			"s":"",//分类信息详情
			"a":""
		}
	}
]
```
##### 字典中key值说明
*  分钟数据字典
	- Q 		Sequence Number
	- T			Time
	- E			Sleep
	- P			Pedo    
	- H			HeartRate
* 	数据分类:Sequence Number
	- 整数
* 	数据分类:Time
	- [hour, minute] //**此处为了节约空间，将日期写在文件名里**
*  	数据分类:Sleep
  	- a			Array
  	- s			shutdown
  	- c			charge 
*  数据分类:Pedo
	- s			Step
	- d			Distance
	- c			Calorie
	- t			Type
	- a			State
* 	数据分类:HeartRate
	- x			MaxBpm
	- n			MinBpm
	- a			AvgBpm

##### 数据示例(Demo)

```
[{
	"E": {
		"a": [30, 70, 55, 0, 10]
	},
	"P": {
		"d": 115,
		"a": 0,
		"s": 18,
		"t": 1,
		"c": 5
	}
},  {
	"E": {
		"a": [4, 16, 8, 0, 140]
	}
}]
```