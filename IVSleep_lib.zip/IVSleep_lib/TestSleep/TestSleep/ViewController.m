//
//  ViewController.m
//  TestSleep
//
//  Created by A$CE on 2017/9/22.
//  Copyright © 2017年 A$CE. All rights reserved.
//
#import "IVSleep.h"
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createDirWithPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] Name:@"Sleep"];
    NSString *dirSleep = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Sleep"];
    [self createDirWithPath:dirSleep Name:@"20190306"];
    [self createFileIfNotExist];
    IVSleep *sleep = [[IVSleep alloc] init];
    NSError *error;
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Sleep"];
    //    uid-152534311232466058-date-20190220-source-P1C-9807
    //    uid-142718124222561643-date-20190306-source-D2-0493.json
    IV_SA_SleepBufInfo sInfo = [sleep ivSleepData:path andUid:142718124222561643 andDate:@"20190306" andDeviceName:@"D2-0493" andError:&error];
    NSLog(@"Total-%d ;Start-%d:%d ;End-%d:%d \nError- %@",sInfo.total,sInfo.data[0].startTime.hour,sInfo.data[0].startTime.minute,sInfo.outSleepTime.hour,sInfo.outSleepTime.minute,error);
    NSLog(@"%d",sInfo.data[1].type);
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)createFileIfNotExist {
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Sleep/20190306/uid-142718124222561643-date-20190306-source-D2-0493.json"];
    BOOL file = [self createFileWithPath:path];
    NSLog(@"====>%d",file);
    if (file) {
        NSString *pathB = [[NSBundle mainBundle] pathForResource:@"uid-142718124222561643-date-20190306-source-D2-0493" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:pathB];
        NSFileHandle *fileHandle = [NSFileHandle fileHandleForUpdatingAtPath:path];
        [fileHandle writeData:data]; //追加写入数据
    }
}

//创建文件
- (BOOL)createFileWithPath:(NSString *)path {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path]) {
        return YES;
    } else {
        return [self createFile:path];
    }
}

//创建文件夹
- (BOOL)createDirWithPath:(NSString *)path Name:(NSString *)name {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *testDirectory = [path stringByAppendingPathComponent:name];
    
    if ([fileManager fileExistsAtPath:testDirectory]) {
        return YES;
    } else {
        // 创建目录
        BOOL res=[fileManager createDirectoryAtPath:testDirectory withIntermediateDirectories:YES attributes:nil error:nil];
        if (res) {
            NSLog(@"文件夹创建成功");
        }else
            NSLog(@"文件夹创建失败");
        
        return res;
    }
}

- (BOOL)createFile:(NSString *)path {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:NSFileProtectionNone
                                                           forKey:NSFileProtectionKey];
    BOOL res=[fileManager createFileAtPath:path contents:nil attributes:attributes];
    
    if (res) {
        NSLog(@"文件创建成功: %@",path);
    }else
        NSLog(@"文件创建失败");
    return res;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
