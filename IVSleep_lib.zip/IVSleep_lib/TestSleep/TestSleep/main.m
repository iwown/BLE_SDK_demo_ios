//
//  main.m
//  TestSleep
//
//  Created by A$CE on 2017/9/22.
//  Copyright © 2017年 A$CE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
