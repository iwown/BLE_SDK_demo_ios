### IVSleep
* P1 watch's sleep algorithm provides new protocol sleep solution; Algorithm input is a set of .txt files.
* D2 watch's sleep algorithm, input is .json files.

### Important
* Strictly follow the file format, there are file examples in sdk. Please refer to the Txtfile directory for P1 watches. The binary data stream is recorded in this file, and each data is separated by "\n". If your watch uses the same protocol as Dong2 Watch, your file format should refer to the file in the FileJson directory. There is also a documentation named Dong2_Sleep_lib_input Json_file_1.3.md

* Abnormal parameter format may cause flashback, please check carefully

* need c++ standard library support, refer to testDemo
